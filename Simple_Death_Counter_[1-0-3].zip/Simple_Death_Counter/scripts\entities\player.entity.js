import { world } from "@minecraft/server";
/**
 * Incrémente le score d'un joueur quand il meurt
 */
export const incrementPlayerScoreWhenDeath = () => {
    world.afterEvents.entityDie.subscribe((eventData) => {
        const playerDead = eventData.deadEntity;
        playerDead.setDynamicProperty("douarmc:keep_death_amount", playerDead.getDynamicProperty("douarmc:keep_death_amount") + 1);
    }, { entityTypes: ["minecraft:player"] });
};
