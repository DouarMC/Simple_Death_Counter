import { world, system, DisplaySlotId } from "@minecraft/server";
/**
 * Gère l'Objectif de score qui affiche le nombre de morts des joueurs
 */
export const manageDeathCounterObjective = () => {
    const deathCounterObjective = world.scoreboard.getObjective("douarmc:death_objective") ?? world.scoreboard.addObjective("douarmc:death_objective", "§cDeaths");
    const objectiveIdSidebarSlot = world.scoreboard.getObjectiveAtDisplaySlot(DisplaySlotId.Sidebar)?.objective.id;
    const objectiveIdBelownameSlot = world.scoreboard.getObjectiveAtDisplaySlot(DisplaySlotId.BelowName)?.objective.id;
    const objectiveIdListSlot = world.scoreboard.getObjectiveAtDisplaySlot(DisplaySlotId.List)?.objective.id;
    if (objectiveIdSidebarSlot !== "deathObjective" && objectiveIdBelownameSlot !== "deathObjective" && objectiveIdListSlot !== "deathObjective") {
        world.scoreboard.setObjectiveAtDisplaySlot(DisplaySlotId.Sidebar, { objective: deathCounterObjective });
    }
    ;
    system.runInterval(() => {
        const players = world.getAllPlayers();
        players.forEach((player) => {
            player.setDynamicProperty("douarmc:keep_death_amount", player.getDynamicProperty("douarmc:keep_death_amount") ?? 0);
            deathCounterObjective.setScore(player, player.getDynamicProperty("douarmc:keep_death_amount"));
        });
        deathCounterObjective.getParticipants().forEach((participant) => {
            try {
                participant.getEntity();
            }
            catch (e) {
                deathCounterObjective.removeParticipant(participant);
            }
            ;
        });
    });
};
