import { world, system } from "@minecraft/server";
/**
 * Reset à 0 le compteur de mort de tous les joueurs à partir d'une commande Scriptevent qui est exexuté si une commande function est executé
 */
export const resetDeathCounterScriptevent = () => system.afterEvents.scriptEventReceive.subscribe((eventData) => {
    const scripteventId = eventData.id;
    /* CONDITION D'ARRÊT */ if (scripteventId !== "douarmc:reset_death_counter")
        return;
    world.getAllPlayers().forEach((player) => {
        player.setDynamicProperty("douarmc:keep_death_amount", 0);
    });
}, { namespaces: ["douarmc"] });
