import * as ALL_EXPORTS from "exports";
ALL_EXPORTS.incrementPlayerScoreWhenDeath();
ALL_EXPORTS.manageDeathCounterObjective();
ALL_EXPORTS.resetDeathCounterScriptevent();
