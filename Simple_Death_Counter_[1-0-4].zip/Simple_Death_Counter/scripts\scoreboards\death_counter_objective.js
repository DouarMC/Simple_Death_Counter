import { DisplaySlotId, system, world } from "@minecraft/server";
// Crée ou récupère le scoreboard DeathCounter et le met dans la Sidebar.
const deathCounterObjective = world.scoreboard.getObjective("douarmc:death_counter")
    ?? world.scoreboard.addObjective("douarmc:death_counter", "§cDeaths");
world.scoreboard.setObjectiveAtDisplaySlot(DisplaySlotId.Sidebar, { objective: deathCounterObjective });
// Définit le score des joueurs avec une DynamicProperty.
system.runInterval(() => {
    const players = world.getAllPlayers();
    players.forEach((player) => {
        player.setDynamicProperty("douarmc:score_death_counter_objective", player.getDynamicProperty("douarmc:score_death_counter_objective") ?? 0);
        deathCounterObjective.setScore(player, player.getDynamicProperty("douarmc:score_death_counter_objective"));
    });
});
// Enlève de l'objectif de Scoreboard les joueurs qui ne sont plus dans le monde.
system.runInterval(() => {
    const deathCounterParticipants = deathCounterObjective.getParticipants();
    deathCounterParticipants.forEach((deathCounterParticipant) => {
        try {
            deathCounterParticipant.getEntity();
        }
        catch (e) {
            deathCounterObjective.removeParticipant(deathCounterParticipant);
        }
        ;
    });
});
