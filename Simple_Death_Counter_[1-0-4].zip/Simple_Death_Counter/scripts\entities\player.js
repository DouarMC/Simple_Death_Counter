import { world } from "@minecraft/server";
// Augmente la DynamicProperty du joueur qui meurt.
world.afterEvents.entityDie.subscribe((eventData) => {
    const deadPlayer = eventData.deadEntity;
    deadPlayer.setDynamicProperty("douarmc:score_death_counter_objective", deadPlayer.getDynamicProperty("douarmc:score_death_counter_objective") + 1);
}, { entityTypes: ["minecraft:player"] });
