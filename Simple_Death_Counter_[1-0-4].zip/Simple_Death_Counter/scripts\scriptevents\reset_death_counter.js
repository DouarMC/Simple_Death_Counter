import { world, system } from "@minecraft/server";
// Scriptevent qui réinitialise le compteur de morts des joueurs à 0.
system.afterEvents.scriptEventReceive.subscribe((eventData) => {
    const scripteventId = eventData.id;
    if (scripteventId !== "douarmc:reset_death_counter")
        return;
    const players = world.getAllPlayers();
    players.forEach((player) => {
        player.setDynamicProperty("douarmc:score_death_counter_objective", 0);
    });
}, { namespaces: ["douarmc"] });
